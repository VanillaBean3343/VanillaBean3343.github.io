# Security Policy

## Supported Versions

Our site, is always being updated. If you come across something wrong, please let us know!

| Version | Supported          |
| ------- | ------------------ |
| v1.0.0  | :white_check_mark: |

## Reporting a Vulnerability

Use this section to tell people how to report a vulnerability.

You can join our bot's support server: https://discord.gg/2nFWe5hGSy 
There you can ask for assistance.
